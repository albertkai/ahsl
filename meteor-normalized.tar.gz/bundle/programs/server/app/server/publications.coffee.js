(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('schedules', function() {
  return Schedules.find();
});

})();

//# sourceMappingURL=publications.coffee.js.map
