(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Autoupdate = Package.autoupdate.Autoupdate;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteor-platform'] = {};

})();

//# sourceMappingURL=meteor-platform.js.map
