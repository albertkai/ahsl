(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Roles = Package['alanning:roles'].Roles;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Accounts = Package['accounts-base'].Accounts;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package.livedata.DDP;
var DDPServer = Package.livedata.DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var __coffeescriptShare;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/aura:core/lib/collections.coffee.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.AuraHistory = new Mongo.Collection('auraHistory');

this.AuraPages = new Mongo.Collection('auraPages');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/aura:core/client/aura.coffee.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
if (Meteor.isClient) {
  console.log('aura is working');
  Session.setDefault('admin.editMode', false);
  Template.auraAdminPanel.helpers({
    history: function() {
      return History.find({}, {
        sort: {
          date: -1
        }
      });
    },
    getDate: function(date) {
      return moment(date).lang('ru').format('DD.MM.YYYY HH:MM');
    }
  });
  Template.auraAdminPanel.events({
    'click #toggle-users': function() {
      return $('#auraUsersModal').addClass('_opened');
    }
  });
  Meteor.subscribe('users');
  Meteor.subscribe('auraPages');
  Meteor.subscribe('auraHistory');
  Template.registerHelper('common', function() {
    return AuraPages.findOne({
      name: 'common'
    });
  });
  Template.registerHelper('index', function() {
    return AuraPages.findOne({
      name: 'index'
    });
  });
  Template.registerHelper('contacts', function() {
    return AuraPages.findOne({
      name: 'contacts'
    });
  });
  Template.registerHelper('children', function() {
    return AuraPages.findOne({
      name: 'children'
    });
  });
  Template.registerHelper('teens', function() {
    return AuraPages.findOne({
      name: 'teens'
    });
  });
  Template.registerHelper('lateTeens', function() {
    return AuraPages.findOne({
      name: 'lateTeens'
    });
  });
  Template.registerHelper('grownUps', function() {
    return AuraPages.findOne({
      name: 'grownUps'
    });
  });
  Meteor.startup(function() {
    $(window).on('blur', function() {
      return console.log('blured');
    });
    $('body').on('click', '.close-modal', function() {
      return $('.auraModal').removeClass('_opened');
    });
    $('body').on('mouseover', '[data-aura-html]', function(e) {
      var target;
      target = $(e.currentTarget);
      target.addClass('_editor-hover');
      return Meteor.setTimeout(function() {
        return target.removeClass('_editor-hover');
      }, 600);
    });
    $('body').on('focus', '[data-aura-html]', function(e) {
      return console.log($(e.currentTarget).html());
    });
    $('body').on('blur', '[data-aura-html]', function(e) {
      return console.log($(e.currentTarget).html());
    });
    Deps.autorun(function() {
      console.log('session worked!');
      if (Session.get('admin.editMode') === true) {
        return $('[contenteditable]').each(function() {
          return $(this).attr('contenteditable', 'true');
        });
      } else {
        return $('[contenteditable]').each(function() {
          return $(this).attr('contenteditable', 'false');
        });
      }
    });
    $('body').on('click', '.logout', function() {
      return Meteor.logout();
    });
    $('body').find('.aura-toggle-edit').on('click', function(e) {
      console.log('changed');
      console.log($(e.currentTarget));
      $(e.currentTarget).toggleClass('_active');
      if ($(e.currentTarget).hasClass('_active')) {
        Session.set('admin.editMode', true);
        return $(e.currentTarget).find('p').text('правка');
      } else {
        Session.set('admin.editMode', false);
        return $(e.currentTarget).find('p').text('просмотр');
      }
    });
    Mousetrap.bind('q w e', function(e) {
      return Aura.showAdminModal();
    });
    Mousetrap.bind('й ц у', function(e) {
      return Aura.showAdminModal();
    });
    Template.auraAdminPanel.events({
      'click #edit-mode': function(e) {
        if ($(e.target).is(':checked')) {
          Session.set('admin.editMode', true);
          return aloha.dom.query('[data-aura-html]', document).forEach(aloha);
        } else {
          Session.set('admin.editMode', false);
          return aloha.dom.query('[data-aura-html]', document).forEach(aloha.mahalo);
        }
      },
      'mouseenter #history-cont li': function(e) {},
      'click #history-cont li': function(e) {
        var target;
        target = $(e.target).closest('li').data('id');
        return Aura._historyRestore(target);
      }
    });
    Template.aura.rendered = function() {
      var script;
      script = document.createElement("script");
      script.type = "text/javascript";
      script.src = '/scripts/ace.js';
      script.id = "ace-script";
      document.body.appendChild(script);
      return $('#ace-script').load(function() {
        return console.log(ace);
      });
    };
    Template.aura.events({
      'click .close span': function() {
        console.log('closing');
        return Aura.hideAdminModal();
      }
    });
    Template.auraLoginModal.events({
      'click .close': function() {
        return Aura.hideAdminModal();
      },
      'click #login': function(e) {
        var email, password;
        e.preventDefault();
        email = $('#login-email').val();
        password = $('#login-password').val();
        return Meteor.loginWithPassword(email, password, function() {
          return Aura.hideAdminModal();
        });
      }
    });
    Template.auraUsersModal.rendered = function() {
      return $('#aura-users-cont > ul > li').first().trigger('click');
    };
    Template.auraUsersModal.helpers({
      allUsers: function() {
        return Meteor.users.find();
      },
      getPermissions: function(roles) {
        var role;
        if (roles) {
          role = roles[0];
          if (role === 'admin') {
            return 'администратор';
          } else if (role === 'owner') {
            return 'владелец';
          }
        }
      },
      isNewUser: function() {
        if (Session.get('auraSelectedUser') === 'new') {
          return true;
        } else {
          return false;
        }
      },
      getImage: function(pic) {
        if (pic) {
          return "background-image: url(http://d22dq06nm2ti3w.cloudfront.net/aura/" + pic + ")";
        } else {
          return '';
        }
      },
      selectedUser: function() {
        var id;
        id = Session.get('auraSelectedUser');
        return Meteor.users.findOne({
          '_id': id
        });
      }
    });
    Template.auraUsersModal.events({
      'click #aura-users-cont > ul > li': function(e) {
        var id;
        if ($(e.currentTarget).hasClass('add-user')) {
          return Session.set('auraSelectedUser', 'new');
        } else {
          id = $(e.currentTarget).data('id');
          $(e.currentTarget).addClass('_active').siblings().removeClass('_active');
          return Session.set('auraSelectedUser', id);
        }
      },
      'click .remove': function(e) {
        var id;
        id = $(e.currentTarget).closest('li').data('id');
        return Meteor.call('auraRemoveUser', id, function(err, res) {
          if (err) {
            return Aura.notify('Пользователь не удален, обратитесь к разработчику');
          } else {
            return Aura.notify('Пользователь удален!');
          }
        });
      }
    });
    Template.auraNewUser.events({
      'click #create-user': function() {
        var options;
        if ($('#user-name').val() !== '' && $('#user-surname').val() !== '' && $('#user-email').val() !== '' && $('#user-password').val() !== '') {
          options = {
            name: $('#user-name').val(),
            surname: $('#user-surname').val(),
            email: $('#user-email').val(),
            password: $('#user-password').val(),
            role: $('#permissions-select').val()
          };
          return Meteor.call('auraCreateUser', options, function(err, res) {
            if (err) {
              return Aura.notify('Упс, что-то не так на сервере:( Обратитесь к разработчику', 'error');
            } else {
              Aura.notify('Ура, пользователь создан!', 'success');
              return console.log(res);
            }
          });
        }
      }
    });
    Template.auraUsersModalSettings.rendered = function() {
      $('.aura-select').select2('destroy');
      return $('.aura-select').select2({
        minimumResultsForSearch: -1
      });
    };
    Template.auraNewUser.rendered = function() {
      $('.aura-select').select2('destroy');
      return $('.aura-select').select2({
        minimumResultsForSearch: -1
      });
    };
    Template.auraUsersModalSettings.helpers({
      getEmail: function(emails) {
        return emails[0].address;
      }
    });
    return Template.auraEditor.events({
      'click button': function(e) {
        return $(e.target).closest('button').toggleClass('_active');
      },
      'click #b-html': function(e) {
        if ($(e.target).hasClass('_active')) {
          $('.editor .html-cont').css('visibility', 'visible').removeClass('flipOutX').addClass('animated flipInX');
          return console.log('this ' + editor._editingItem);
        } else {
          return $('.editor .html-cont').removeClass('flipInX').addClass('flipOutX');
        }
      },
      'click .editor .html-cont button': function(e) {
        var val;
        val = $('.editor .html-cont').data('resetData');
        return editor.auraEditorHtml.setValue(val);
      },
      'blur .editor .html-cont textarea': function(e) {
        return $($(e.target).data('path')).trigger('blur');
      },
      'click #b-bold': function() {
        return editor.commands.bold();
      },
      'click #b-italic': function() {
        return editor.commands.italic();
      },
      'click #b-sub': function() {
        return editor.commands.sub();
      },
      'click #b-sup': function() {
        return editor.commands.sup();
      },
      'click #b-ul': function() {
        return editor.commands.ul();
      },
      'click #b-ol': function() {
        return editor.commands.ol();
      },
      'click #b-h1': function() {
        return editor.commands.h1();
      },
      'click #b-h2': function() {
        return editor.commands.h2();
      },
      'click #b-h3': function() {
        return editor.commands.h3();
      },
      'click #b-h4': function() {
        return editor.commands.h4();
      },
      'click #b-h5': function() {
        return editor.commands.h5();
      },
      'click #b-h6': function() {
        return editor.commands.h6();
      },
      'click #b-span': function() {
        return editor.commands.span();
      },
      'click #b-link': function() {
        return editor.commands.link();
      },
      'click #b-save': function(e) {
        editor.hideEditor();
        return editor.save();
      }
    });
  });
}

if (Meteor.isClient) {
  console.log('visible');
  Meteor.startup(function() {
    $('body').on('focus', '[contenteditable="true"]', 'focus', function(e) {
      var data, markup;
      console.log('focused');
      data = $(e.currentTarget).html();
      markup = $.htmlClean(data, {
        format: true
      });
      editor.showEditor(markup);
      editor._trackChanges.currentValue = data;
      editor.editingItem = data;
      $('.editor .html-cont').data('resetData', markup);
      return $('.editor .html-cont').data('path', $(e.target).closest('[contenteditable="true"]').getPath());
    });
    $('body').on('blur', '[contenteditable="true"]', function(e) {
      var currentState, fieldData, fields, indexField;
      console.log('blurred');
      if (!editor.blured) {
        currentState = $(e.currentTarget).html();
        if (currentState !== editor.editingItem) {
          fieldData = $(e.target).data('field');
          $('.editor .html-cont textarea').data('index', Aura._historyBuffer.length);
          fields = (function() {
            var id;
            if (fieldData.match(/^\$/)) {
              id = $(e.target).closest('[data-nested-id]').data('nested-id');
              return {
                field: fieldData.split('.')[2],
                nested: {
                  id: id,
                  type: 'array',
                  field: fieldData.split('.')[1]
                }
              };
            } else if (fieldData.match(/\./)) {
              return {
                field: fieldData.split('.')[1],
                nested: {
                  type: 'prop',
                  field: fieldData.split('.')[0]
                }
              };
            } else {
              return {
                field: fieldData,
                nested: null
              };
            }
          })();
          indexField = (function() {
            if ($(e.target).closest('[data-document]').data('index-field')) {
              return $(e.target).closest('[data-document]').data('index-field');
            } else {
              return '_id';
            }
          })();
          Aura._historyBuffer.push({
            field: $(e.target).data('field'),
            document: $(e.target).closest('[data-document]').data('document'),
            indexField: indexField,
            collection: $(e.target).closest('[data-collection]').data('collection'),
            data: editor.editingItem,
            newData: $(e.target).closest('[contenteditable="true"]').html(),
            selectorPath: $(e.target).getPath(),
            type: 'text',
            rolledBack: false,
            changable: true,
            nested: fields.nested
          });
          editor._changedBuffer.push({
            field: fields.field,
            document: $(e.target).closest('[data-document]').data('document'),
            collection: $(e.target).closest('[data-collection]').data('collection'),
            indexField: indexField,
            data: $(e.target).closest('[contenteditable="true"]').html(),
            nested: fields.nested
          });
          console.log(editor._changedBuffer);
          console.log(Aura._historyBuffer);
          $(e.target).closest('[contenteditable="true"]').addClass('_changed');
          editor.blured = true;
          return Meteor.setTimeout(function() {
            return editor.blured = false;
          }, 1000);
        }
      }
    });
    return Template.body.events({
      'focus [contenteditable="true"]': function(e) {
        var data, markup;
        console.log('focused');
        data = $(e.currentTarget).html();
        markup = $.htmlClean(data, {
          format: true
        });
        editor.showEditor(markup);
        editor._trackChanges.currentValue = data;
        editor.editingItem = data;
        $('.editor .html-cont').data('resetData', markup);
        return $('.editor .html-cont').data('path', $(e.target).closest('[contenteditable="true"]').getPath());
      },
      'input [contenteditable="true"]': function(e) {
        var markup;
        markup = $(e.target).html();
        return editor.auraEditorHtml.setValue($.htmlClean(markup, {
          format: true
        }));
      },
      'click #admin-login-modal .close': function() {
        return Aura.hideAdminModal();
      },
      'submit #aura-login-form': function(e) {
        var email, password;
        e.preventDefault();
        email = $('#aura-login-form').find('#email').val();
        password = $('#aura-login-form').find('#password').val();
        Meteor.loginWithPassword(email, password, function(err) {
          if (err) {
            return Aura.notify('Ошибочка:(');
          } else {
            Aura.notify('Добро пожаловать!');
            return Aura.hideAdminModal();
          }
        });
        return false;
      },
      'blur [contenteditable="true"]': function(e) {
        var currentState, fieldData, fields, indexField;
        console.log('blurred');
        if (!editor.blured) {
          currentState = $(e.currentTarget).html();
          if (currentState !== editor.editingItem) {
            fieldData = $(e.target).data('field');
            $('.editor .html-cont textarea').data('index', Aura._historyBuffer.length);
            fields = (function() {
              var id;
              if (fieldData.match(/^\$/)) {
                id = $(e.target).closest('[data-nested-id]').data('nested-id');
                return {
                  field: fieldData.split('.')[2],
                  nested: {
                    id: id,
                    type: 'array',
                    field: fieldData.split('.')[1]
                  }
                };
              } else if (fieldData.match(/\./)) {
                return {
                  field: fieldData.split('.')[1],
                  nested: {
                    type: 'prop',
                    field: fieldData.split('.')[0]
                  }
                };
              } else {
                return {
                  field: fieldData,
                  nested: null
                };
              }
            })();
            indexField = (function() {
              if ($(e.target).closest('[data-document]').data('index-field')) {
                return $(e.target).closest('[data-document]').data('index-field');
              } else {
                return '_id';
              }
            })();
            Aura._historyBuffer.push({
              field: $(e.target).data('field'),
              document: $(e.target).closest('[data-document]').data('document'),
              indexField: indexField,
              collection: $(e.target).closest('[data-collection]').data('collection'),
              data: editor.editingItem,
              newData: $(e.target).closest('[contenteditable="true"]').html(),
              selectorPath: $(e.target).getPath(),
              type: 'text',
              rolledBack: false,
              changable: true,
              nested: fields.nested
            });
            editor._changedBuffer.push({
              field: fields.field,
              document: $(e.target).closest('[data-document]').data('document'),
              collection: $(e.target).closest('[data-collection]').data('collection'),
              indexField: indexField,
              data: $(e.target).closest('[contenteditable="true"]').html(),
              nested: fields.nested
            });
            console.log(editor._changedBuffer);
            console.log(Aura._historyBuffer);
            $(e.target).closest('[contenteditable="true"]').addClass('_changed');
            editor.blured = true;
            return Meteor.setTimeout(function() {
              return editor.blured = false;
            }, 1000);
          }
        }
      },
      'change .aura-edit-image input[type="file"]': function(e) {
        var file, fr, input;
        input = $(e.target);
        file = input.get(0).files[0];
        fr = new FileReader();
        MainCtrl.showLoader();
        fr.onload = function() {
          var currentPic, pic, target;
          pic = {};
          pic['data'] = fr.result;
          pic['name'] = file.name;
          pic['size'] = file.size;
          pic['type'] = file.type;
          currentPic = (function() {
            var path;
            if ($(e.target).closest('[data-image]').data('image-target') === 'background') {
              path = $(e.target).closest('[data-image]').css('background-image');
              return _.last(path.split('/')).replace(')', '');
            } else {
              path = $(e.target).closest('[data-image]').attr('src');
              return _.last(path.split('/'));
            }
          })();
          target = $(e.target).closest('[data-image]').data('image-target') || 'img';
          return (new PNotify({
            title: 'Удалить старое изображение?',
            text: 'Желательно удалять, чтобы не перегружать хостинг',
            hide: false,
            addclass: 'aura-notify',
            confirm: {
              confirm: true
            },
            buttons: {
              closer: false,
              sticker: false
            },
            history: {
              history: false
            }
          })).get().on('pnotify.confirm', function() {
            return Aura.media.updatePic(e, pic, file, target, currentPic);
          }).on('pnotify.cancel', function() {
            return Aura.media.uploadPic(e, pic, file, target);
          });
        };
        return fr.readAsBinaryString(file);
      },
      'change .auraModal .list-cont .add input[type="file"]': function(e) {
        var file, fr, id, input;
        console.log('triggered change');
        input = $(e.target);
        file = input.get(0).files[0];
        id = $('#albumId').val();
        fr = new FileReader();
        MainCtrl.showLoader();
        return Aura.media.resizeAndUpload(id, file);
      },
      'dragover [data-image]': function(e) {
        if (e.preventDefault) {
          e.preventDefault();
        }
        $(e.target).closest('[data-image]').addClass('_hover');
        return false;
      },
      'dragenter [data-image]': function(e) {
        if (e.preventDefault) {
          e.preventDefault();
        }
        $(e.target).closest('[data-image]').addClass('_hover');
        return false;
      },
      'dragleave [data-image]': function(e) {
        $(e.target).closest('[data-image]').removeClass('_hover');
        return false;
      },
      'drop [data-image]': function(e) {
        var file, fr;
        e.preventDefault();
        e.stopPropagation();
        $(e.target).removeClass('_hover');
        file = e.originalEvent.dataTransfer.files[0];
        fr = new FileReader();
        MainCtrl.showLoader();
        fr.onload = function() {
          var currentPic, pic, target;
          pic = {};
          pic['data'] = fr.result;
          pic['name'] = file.name;
          pic['size'] = file.size;
          pic['type'] = file.type;
          currentPic = (function() {
            var path;
            if ($(e.target).closest('[data-image]').data('image-target') === 'background') {
              path = $(e.target).closest('[data-image]').css('background-image');
              return _.last(path.split('/')).replace(')', '');
            } else {
              path = $(e.target).closest('[data-image]').attr('src');
              return _.last(path.split('/'));
            }
          })();
          target = $(e.target).closest('[data-image]').data('image-target') || 'img';
          return (new PNotify({
            title: 'Удалить старое изображение?',
            text: 'Желательно удалять, чтобы не перегружать хостинг',
            hide: false,
            confirm: {
              confirm: true
            },
            buttons: {
              closer: false,
              sticker: false
            },
            history: {
              history: false
            }
          })).get().on('pnotify.confirm', function() {
            return Aura.media.updatePic(e, pic, file, target, currentPic, false);
          }).on('pnotify.cancel', function() {
            return Aura.media.uploadPic(e, pic, file, target, false);
          });
        };
        return fr.readAsBinaryString(file);
      },
      'mouseenter .aura-edit-image': function(e) {
        return $(e.target).closest('[data-image]').addClass('_hover');
      },
      'mouseleave .aura-edit-image': function(e) {
        return $(e.target).closest('[data-image]').removeClass('_hover');
      },
      'click .aura-toggle-edit': function(e) {
        $(e.currentTarget).toggleClass('_active');
        if ($(e.currentTarget).hasClass('_active')) {
          Session.set('admin.editMode', true);
          return $(e.currentTarget).find('p').text('правка');
        } else {
          Session.set('admin.editMode', false);
          return $(e.currentTarget).find('p').text('просмотр');
        }
      }
    });
  });
}

this.Aura = {
  showAdminModal: function() {
    return $('#admin-login-modal').css('visibility', 'visible').removeClass('flipOutY').addClass('animated flipInY');
  },
  hideAdminModal: function() {
    $('#admin-login-modal').removeClass('flipInY').addClass('flipOutY');
    return setTimeout(function() {
      return $('#admin-login-modal').css('visibility', 'hidden');
    }, 500);
  },
  notify: function(message) {
    return new PNotify({
      title: 'Спасибо!',
      text: message,
      addclass: 'aura-notify'
    });
  },
  saveContent: function(name, query, newContent, prevContent) {
    return Meteor.call('saveContent', name, query, newContent, function(err, res) {});
  },
  media: {
    uploadPic: function(e, pic, file, target) {
      return Meteor.call('uploadPic', pic, function(err, res) {
        var collection, document, fieldName, indexField, newData, query, targetId;
        if (err) {
          MainCtrl.hideLoader();
          return Aura.notify('Произошла ошибка, обратитесь к разработчику!');
        } else {
          if (res) {
            console.log(file.name);
            fieldName = $(e.target).closest('[data-image]').data('image');
            document = $(e.target).closest('[data-document]').data('document');
            indexField = $(e.target).closest('[data-document]').data('index-field') || '_id';
            collection = $(e.target).closest('[data-collection]').data('collection');
            query = {};
            newData = {};
            query[indexField] = document;
            newData[fieldName] = file.name;
            targetId = eColl[collection].findOne(query)._id;
            return eColl[collection].update(targetId, {
              $set: newData
            }, function() {
              if (target === 'background') {
                return $('<img>').attr('src', 'http://d9bm0rz9duwg1.cloudfront.net/' + file.name).load(function() {
                  MainCtrl.hideLoader();
                  $(e.target).closest('[data-image]').css('background-image', 'url(http://d9bm0rz9duwg1.cloudfront.net/' + file.name + ')');
                  $(e.target).closest('[data-image]').width($(window).width());
                  $(e.target).closest('[data-image]').siblings('[data-image]').width($(window).width());
                  return Aura.notify('Изображение обновлено, спасибо!');
                });
              } else if (target === 'img') {
                return $('<img>').attr('src', 'http://d9bm0rz9duwg1.cloudfront.net/' + file.name).load(function() {
                  MainCtrl.hideLoader();
                  return $(e.target).closest('[data-image]').attr('src', 'url(http://d9bm0rz9duwg1.cloudfront.net/' + file.name);
                });
              }
            });
          } else {
            MainCtrl.hideLoader();
            return Aura.notify('Произошла ошибка, обратитесь к разработчику!');
          }
        }
      });
    },
    updatePic: function(e, pic, file, target, currentPic) {
      return Meteor.call('deletePic', currentPic, function(err, res) {
        if (err) {
          return Aura.notify('Изображение не удалено:( Может и к лучшему))');
        } else {
          if (res) {
            return Aura.media.uploadPic(e, pic, file, target);
          } else {
            return Aura.notify('Изображение не удалено:( Ошибка на стороне сервера');
          }
        }
      });
    },
    resizeAndUpload: function(id, file) {
      var deferred, originalFile, pic, resize, resizedPic;
      console.log('triggered upload with resize');
      pic = {};
      resizedPic = {};
      deferred = $.Deferred();
      resize = function() {
        var reader;
        reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onLoad = function(e) {
          return $.canvasResize(file, {
            width: 300,
            height: 0,
            crop: false,
            quality: 80,
            callback: function(data) {
              deferred.resolve(data);
              return console.log({
                data: data
              });
            }
          });
        };
        return deferred.promise();
      };
      originalFile = function() {
        var reader;
        reader = new FileReader();
        deferred = $.Deferred();
        reader.readAsBinaryString(file);
        reader.onload = function(e) {
          var ifile;
          ifile = reader.result;
          deferred.resolve(ifile);
          return console.log({
            reader: ifile
          });
        };
        return deferred.promise();
      };
      return $.when(originalFile(), resize()).done((function(_this) {
        return function(ifile, resizedFile) {
          console.log('resolved');
          pic['fileInfo'] = file;
          pic['data'] = ifile;
          resizedPic['fileInfo'] = file;
          resizedPic['data'] = resizedFile;
          console.log(pic);
          console.log(resizedPic);
          return Meteor.call('uploadWithThumb', [pic, resizedPic], function(err, res) {
            if (err) {
              return Aura.notify('Упс, что-то пошло не так:(');
            } else {
              if (res) {
                console.log(res);
                return Gallery.update(id, {
                  $push: {
                    'images': res
                  }
                }, function() {
                  Aura.notify('Изображение ' + res + ' добавлено!');
                  return MainCtrl.hideLoader();
                });
              } else {
                return Aura.notify('Что-то пошло не так, обратитесь к разработчику!');
              }
            }
          });
        };
      })(this));
    },
    deletePic: function(pic) {
      return Meteor.call('deletePic', pic, function(err, res) {
        if (err) {
          return Aura.notify('Изображение не удалено:( Может и к лучшему))');
        } else {
          if (res) {
            return Aura.notify('Изображение успешно удалено!');
          } else {
            return Aura.notify('Изображение не удалено:( Ошибка на стороне сервера');
          }
        }
      });
    },
    deletePics: function(pics) {
      return Meteor.call('deletePics', pics, function(err, res) {
        if (err) {
          return Aura.notify('Изображения не удалены:( Может и к лучшему))');
        } else {
          if (res) {
            return Aura.notify('Изображения успешно удалено!');
          } else {
            return Aura.notify('Изображения не удалены:( Ошибка на стороне сервера');
          }
        }
      });
    }
  },
  _logsWrite: function(buffer) {
    return _.each(buffer, function(log) {
      return Logs.insert({
        field: log.field,
        collection: log.collection,
        date: new Date(),
        user: 'Albert Kai'
      });
    });
  },
  _historyBuffer: [],
  _saveHistory: function(buffer) {
    var historyCount, toDelete, toDeleteSize;
    console.log('triggered saveHistory');
    historyCount = History.find().count();
    if (historyCount + buffer.length > Aura.settings.history.size) {
      toDeleteSize = historyCount + buffer.length - Aura.settings.history.size;
      toDelete = History.find({}, {
        sort: {
          date: 1
        },
        limit: toDeleteSize
      }).fetch();
      toDelete.forEach(function(item) {
        var id;
        id = item._id;
        return History.remove(id);
      });
    }
    _.each(buffer, function(history) {
      var target;
      if (!history.rolledBack) {
        History.insert({
          field: history.field,
          collection: history.collection,
          document: history.document,
          indexField: history.indexField,
          date: new Date(),
          data: history.data,
          selectorPath: history.selectorPath,
          newData: history.newData,
          type: history.type,
          user: Meteor.user(),
          rolledBack: history.rolledBack,
          changable: history.changeable
        });
        return console.log('triggered saveHistory iterate');
      } else {
        target = History.findOne({
          _id: history._id
        });
        target.rolledBack = !buffer.rolledBack;
        return History.update({
          _id: history._id
        }, history);
      }
    });
    return Aura._historyBuffer = [];
  },
  _historyRestore: function(id) {
    var changedBuffer, historyItem, restoredBuffer;
    historyItem = History.findOne({
      _id: id
    });
    if (historyItem.rolledBack) {
      restoredBuffer = [];
      restoredBuffer.push({
        field: historyItem.field,
        document: historyItem.document,
        collection: historyItem.collection,
        indexField: historyItem.indexField,
        data: historyItem.newData,
        nested: historyItem.nested
      });
      console.log(restoredBuffer);
      return editor.editorSaveText(restoredBuffer, function() {
        History.update({
          _id: id
        }, {
          $set: {
            rolledBack: false
          }
        });
        return console.log('history restored');
      });
    } else {
      changedBuffer = [];
      changedBuffer.push({
        field: historyItem.field,
        document: historyItem.document,
        collection: historyItem.collection,
        indexField: historyItem.indexField,
        data: historyItem.data,
        nested: historyItem.nested
      });
      console.log(changedBuffer);
      return editor.editorSaveText(changedBuffer, function() {
        History.update({
          _id: id
        }, {
          $set: {
            rolledBack: true
          }
        });
        return console.log('history restored');
      });
    }
  },
  users: {
    addUser: function(object) {
      return Meteor.call('auraAddUser', function(options) {});
    }
  }
};

this.editor = {
  blured: false,
  _editingItem: '',
  _changedBuffer: [],
  commands: {
    bold: function() {
      return document.execCommand('bold', null, null);
    },
    italic: function() {
      return document.execCommand('italic', null, null);
    },
    sub: function() {
      return document.execCommand('subscript', null, null);
    },
    sup: function() {
      return document.execCommand('superscript', null, null);
    },
    ul: function() {
      return document.execCommand('insertUnorderedList', null, null);
    },
    ol: function() {
      return document.execCommand('insertOrderedList', null, null);
    },
    h1: function() {
      return document.execCommand('formatBlock', null, '<h1>');
    },
    h2: function() {
      return document.execCommand('formatBlock', null, '<h2>');
    },
    h3: function() {
      return document.execCommand('formatBlock', null, '<h3>');
    },
    h4: function() {
      return document.execCommand('formatBlock', null, '<h4>');
    },
    h5: function() {
      return document.execCommand('formatBlock', null, '<h5>');
    },
    h6: function() {
      return document.execCommand('formatBlock', null, '<h6>');
    },
    span: function() {
      return document.execCommand('formatBlock', null, '<span>');
    },
    link: function() {
      return document.execCommand('createLink', false, prompt('Введите URL'));
    }
  },
  save: function() {
    if (this._changedBuffer.length > 0) {
      return this._saveText(this._changedBuffer);
    }
  },
  _trackChanges: {
    currentValue: '',
    check: function($el) {
      console.log(this.currentValue);
      if ($el.html() !== this.currentValue) {
        return true;
      } else {
        return false;
      }
    }
  },
  _saveText: function(buffer) {
    editor.editorSaveText(buffer, function() {
      Aura._logsWrite(Aura._historyBuffer);
      Aura._saveHistory(Aura._historyBuffer);
      editor._changedBuffer = [];
      console.log('changed');
      return Aura.notify('Изменения сохранены!');
    });
    return true;
  },
  editorSaveText: function(changedBuffer, callback) {
    var user;
    console.log(changedBuffer);
    user = Meteor.user();
    if (Roles.userIsInRole(user, ['admin'])) {
      console.log('triggered saveText');
      return _.each(changedBuffer, function(change) {
        var newData, pageId, query, updateObj;
        if (!change.nested) {
          console.log('triggered saveText iterate');
          newData = {};
          query = {};
          query[change.indexField] = change.document;
          pageId = eColl[change.collection].findOne(query)._id;
          newData[change.field] = change.data;
          eColl[change.collection].update(pageId, {
            $set: newData
          }, function() {
            console.log('saved');
            return console.log(change.data);
          });
          return callback();
        } else if (change.nested.type === 'array') {
          console.log('triggered saveText iterate array');
          newData = {};
          query = {};
          query[change.indexField] = change.document;
          updateObj = {};
          updateObj['_id'] = eColl[change.collection].findOne(query)._id;
          console.log(eColl[change.collection].findOne({
            'name': change.document
          })._id);
          updateObj[change.nested.field + '.id'] = change.nested.id;
          newData[change.nested.field + '.$.' + change.field] = change.data;
          eColl[change.collection].update(updateObj, {
            $set: newData
          }, function() {
            return console.log('saved');
          });
          return callback();
        }
      });
    } else {
      return Meteor.Error(403, 'Not allowed');
    }
  },
  showEditor: function(val) {
    $('.editor').addClass('_opened');
    $('.editor').find('button').removeClass('_active');
    return editor.auraEditorHtml.setValue(val);
  },
  hideEditor: function() {
    $('.editor').removeClass('_opened');
    return $('.editor').find('.html-cont').removeClass('flipInX').addClass('flipOutX');
  }
};

Aura.settings = {
  history: {
    size: 50
  }
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/aura:core/server/server.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
console.log('Aura server initialized');

Meteor.publish('auraPages', function() {
  return AuraPages.find();
});

Meteor.publish('users', function() {
  return Meteor.users.find();
});

if (Meteor.isServer) {
  Meteor.startup(function() {
    this.Future = Npm.require('fibers/future');
    this.fs = Npm.require('fs');
    this.AWS = Npm.require('aws-sdk');
    process.env.MAIL_URL = 'smtp://postmaster@sandbox32926.mailgun.org:5ty-i8q8jz-3@smtp.mailgun.org:587';
    return AWS.config.update({
      accessKeyId: 'AKIAJKHELBJSF7V6D7FQ',
      secretAccessKey: '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'
    });
  });
}

if (Meteor.isServer) {
  Meteor.methods({
    uploadPic: function(pic) {
      var buffer, f, newName, origImage, s3;
      s3 = new AWS.S3();
      buffer = new Buffer(pic.data, 'binary');
      newName = (function() {
        var extention, randomName;
        extention = _.last(pic.name.split('.'));
        randomName = Random.id();
        return randomName + '.' + extention;
      })();
      origImage = {
        Key: newName,
        ContentType: pic.type,
        Body: buffer,
        Bucket: 'ahsl/aura'
      };
      f = new Future();
      s3.putObject(origImage, function(err, data) {
        if (err) {
          console.log(err);
          return f["return"](false);
        } else {
          console.log('object ' + pic.name + ' with new name ' + newName + ' uploaded to S3! Congrats!');
          return f["return"](true);
        }
      });
      return f.wait();
    },
    uploadWithThumb: function(pics) {
      var f, newName, origBuffer, origImage, resizedBuffer, resizedImage, s3;
      s3 = new AWS.S3();
      origBuffer = new Buffer(pics[0].data, 'binary');
      resizedBuffer = new Buffer(pics[1].data, 'binary');
      newName = (function() {
        var extention, randomName;
        extention = _.last(pics[0].fileInfo.name.split('.'));
        randomName = Random.id();
        return {
          orig: randomName + '.' + extention,
          thumb: randomName + '_thumb.' + extention
        };
      })();
      origImage = {
        Key: newName.orig,
        ContentType: pics[0].fileInfo.type,
        Body: origBuffer,
        Bucket: 'ahsl/aura'
      };
      resizedImage = {
        Key: newName.thumb,
        ContentType: pics[0].fileInfo.type,
        Body: resizedBuffer,
        Bucket: 'ahsl/aura'
      };
      f = new Future();
      s3.putObject(origImage, function(err, data) {
        if (err) {
          console.log(err);
          return f["return"](false);
        } else {
          console.log('object ' + pics[0].fileInfo.name + 'named ' + newName.orig + ' uploaded to S3! Congrats!');
          return f["return"](true);
        }
      });
      f.wait();
      f = new Future();
      s3.putObject(resizedImage, function(err, data) {
        if (err) {
          console.log(err);
          return f["return"](false);
        } else {
          console.log('object ' + pics[1].fileInfo.name + ' thumb named' + newName.thumb + 'uploaded to S3');
          return f["return"](true);
        }
      });
      f.wait();
      return newName.orig;
    },
    deletePic: function(pic) {
      var f, params, s3;
      s3 = new AWS.S3();
      params = {
        Bucket: 'ahsl/aura',
        Key: pic
      };
      f = new Future();
      s3.deleteObject(params, function(err, data) {
        if (err) {
          console.log(err, err.stack);
          return f["return"](false);
        } else {
          console.log('object ' + pic + ' deleted from S3');
          return f["return"](true);
        }
      });
      return f.wait();
    },
    deletePics: function(pics) {
      var f, params, s3;
      if (pics.length > 0) {
        s3 = new AWS.S3();
        params = {
          Bucket: 'ahsl/aura',
          Delete: {
            Objects: []
          }
        };
        pics.forEach(function(pic) {
          var obj;
          obj = {};
          obj['Key'] = pic;
          return params.Delete.Objects.push(obj);
        });
        f = new Future();
        s3.deleteObjects(params, function(err, data) {
          if (err) {
            console.log(err, err.stack);
            return f["return"](false);
          } else {
            console.log('object ' + pics + ' deleted from S3');
            return f["return"](true);
          }
        });
        return f.wait();
      } else {
        console.log('no pics to delete');
        return true;
      }
    },
    auraCreateUser: function(options) {
      var loggedInUser, user;
      loggedInUser = Meteor.user();
      if (Roles.userIsInRole(loggedInUser, ['owner'])) {
        user = Accounts.createUser({
          username: options.name,
          email: options.email,
          password: options.password,
          profile: {
            name: options.name,
            surname: options.surname
          }
        });
        Roles.addUsersToRoles(user, options.role);
        return user;
      } else {
        return 'Permission denied';
      }
    },
    auraRemoveUser: function(id) {
      var loggedInUser;
      loggedInUser = Meteor.user();
      if (Roles.userIsInRole(loggedInUser, ['owner'])) {
        return Meteor.users.remove({
          '_id': id
        });
      }
    }
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/aura:core/server/seed.coffee.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
AuraPages.remove({
  '_id': AuraPages.findOne({
    name: 'common'
  })._id
});

AuraPages.remove({
  '_id': AuraPages.findOne({
    name: 'index'
  })._id
});

if (AuraPages.find({
  name: 'common'
}).count() === 0) {
  AuraPages.insert({
    name: 'common',
    phoneMain: '(812) 345-54-54',
    phoneSecond: '(812) 344-53-53',
    emailMain: 'info@sisi-elizabeth.com',
    address: 'Санкт-Петербург, Суворовский пр. 34, Austrian Higher School of Ladies',
    footerDesc: '<span><strong>2012-2014</strong> Austrian Higher School of Ladies. </span> Все права защищены.',
    vkLink: 'http://vk.com',
    facebookLink: 'http://facebook.com',
    twitterLink: 'http://twitter.com',
    instagramLink: 'http://instagram.com'
  });
}

if (AuraPages.find({
  name: 'directions'
}).count() === 30) {
  AuraPages.insert({
    name: 'directions',
    directions: {
      children: {
        mainImage: '§'
      }
    }
  });
}

if (AuraPages.find({
  name: 'index'
}).count() === 0) {
  AuraPages.insert({
    name: 'index',
    header1: 'О школе',
    header2: 'Новости',
    header3: 'Ближайшие события',
    header4: 'Расписание',
    header5: 'Партнеры',
    header6: 'Направления',
    mainDesc: '<p class="quot"> Австрийская Высшая Школа Леди была основана  в 1867 году под патронажем Австрийской императрицы Сиси Элизабет </p> <p> Школа специализируется на обучении и профессиональной подготовке девушек из высшего общества по передовым международным образовательным программам в области искусства, дизайна, этикета и другим, необходимым для каждой леди, прикладным предметам. Австрийская Высшая Школа Леди в  г. Санкт-Петербург является одним из важнейших образовательных центров России для девушек, специализирующаяся на профессиональном образовании в сфере творческих и гуманитарных дисциплин. </p> <p> В основе развития данного образовательного центра лежит тесная партнерская связь с творческими и культурными нововведениями международного сообщества. По окончании института лишь шесть лучших выпускниц (подростковой группы)  получат  «шифр» - золотой вензель в виде инициала императрицы  Сиси Елизабет, и примут участие в выпускном бале в качестве  дебютанток в Венском Ховбурге.</p> <p>Уникальное преимущество Австрийской Высшей Школы Леди  заключается в возможности получения высшего образования для  девушек в России в соответствии со строжайшими международными стандартами. Эту возможность предоставляют учебные программы, аккредитованные  Quality Assurance Agency - независимым агентством по контролю качества высшего образования. Основной принцип заключается в том, что курсы австрийского образования, предлагаемые в России, проводятся, в большинстве своем, иностранными профессионалами в своей сфере. </p>'
  });
}

if (AuraPages.find({
  name: 'contacts'
}).count() === 0) {
  AuraPages.insert({
    name: 'contacts',
    emailMain: 'ladiesschool@me.com - <span>менеджер</span>',
    emailSecondary: 'ladiesschool@me.com - <span>для записи</span>',
    phoneHeader: 'Телефон:',
    emailHeader: 'E-mail:',
    addressHeader: 'Адрес:',
    allQuestions: 'По всем вопросам звоните:',
    weWillContactU: 'Либо оставьте нам заявку, и мы свяжемся с вами в ближайшее время:'
  });
}

if (AuraPages.find({
  name: 'children'
}).count() === 0) {
  AuraPages.insert({
    name: 'children',
    heading: '<span>Детская</span><span>группа</span>',
    mainPic: 'direction_bg3.jpg',
    mainDesc: '<p>	Леди, которая сегодня вызывает восхищение, еще вчера была девочкой лет 4-х… Как же происходит эта сказочная метаморфоза?</p><p> Все ценное закладывается  в детстве! Поэтому мы маленьких леди обучаем этикету  - как представиться, как попрощаться, за что отвечает каждая ложечка на столе…  Мы любуемся импрессионистами  и рисуем полет бабочки. Мы изучаем по сказкам Европы историю костюма!  Мы учимся красиво и без конфликта заявлять права на свою куклу в саду. Мы позируем … Играем в театр… И конечно, впервые открываем волшебный мир гардеробной. </p>',
    mainQuot: 'Австрийская Высшая Школа Леди в  г. Санкт-Петербург является одним из важнейших образовательных центров России для девочек  и девушек',
    classes: [
      {
        name: 'Этикет',
        desc: '<p class="quot">Как представиться. Как поприветствовать. Как попрощаться. В столовом этикете малыши будут изучать роль каждого столового прибора. И учиться пить чай по книгам Льюиса Кэролла</p> <p>Основные темы – столовый этикет и этикет общения. Программа этикета и хороших манер поможет развить устойчивые поведенческие навыки, которые позволят в дальнейшем чувствовать себя уверенно в любой ситуации, связанной с  общением. </p>',
        pic: 'etiket.jpg'
      }, {
        name: 'Стилистика',
        desc: '<p class="quot"> История костюма изучается по сказкам, по полотнам известных художников. Стили и стилевые направления для маленьких леди открываются через бренды, создающие коллекции для детей – от Dior до Dolce & Gabbana! </p><p>Они научатся отличать классический стиль от фольклорного, романтический от casual  и многое другое. Также мы будем изучать на практике гардероб настоящей Леди! Изучим темы от цвета (а ведь у каждого свой характер! И не все цвета хотят дружить друг с другом!) до сказочной темы шляпок и не только! </p>',
        pic: 'stilistika.jpg'
      }, {
        name: 'Имиджеология',
        desc: '<p>Девочки овладеют навыками искусства  самопрезентации с помощью практических занятий.. Узнают секреты как оставить  положительное впечатление в памяти своих друзей. Определят  свои сильные качества и  узнают  как их использовать в их детском мире. Научаться различать имидж плохого и хорошего героя на примере сказок. Узнают как формируется имидж в классе или в детском саду. Из чего имидж складывается, как формируется и как управляется.  </p>',
        pic: 'imidzeologia.jpg'
      }, {
        name: 'Верховая езда',
        desc: '<p class="quot"> Уроки верховой езды   проходят  в элитном конно-спортивном  клубе  «ДЕРБИ», расположенном  в живописном уголке Ленинградской области.  Ведь каждая будущая леди должна уметь уверенно держаться в седле, легко управляться с лошадью и вести светскую беседу.</p><p>Девочкам проводится краткий рассказ об истории отношений человека и лошади.  Первоначальные  практические занятия включают в себя  обучение правильной посадке, основам управления  </p>',
        pic: 'verhovaya.jpg'
      }, {
        name: 'Актерское мастерство',
        desc: '<p class="quot">Актерское мастерство - это быстрый и увлекательный способ научиться спонтанной импровизации.</p><p>В течение учебного процесса  девочки освободятся   от комплексов и  зажатости,  разовьют  в себе наблюдательность и вовлеченность в творческий процесс, а так же обретут  уверенность в себе. На практических занятиях девочки будут перевоплощаться в различные образы и готовить небольшие спектакли для благодарной родительской аудитории.  </p>',
        pic: 'akterskoe.jpg'
      }, {
        name: 'Хореография',
        desc: '<p class="quot">Главным достижением на уроках хореографии это – правильная осанка, пластичность, грациозность и легкость движений, уравновешенность, улучшение способности концентрироваться, укрепление здоровья, формирование сильного и гибкого тела.</p><p>В программу занятий входят упражнения по укреплению мышц и развития пластичности, постановку правильной осанки, походки, увеличения эластичности связок (растяжки), включая игровые и танцевальные элементы. </p>',
        pic: 'horeografia.jpg'
      }, {
        name: 'Английский язык',
        desc: '<p class="quot">Все занятия  проходят  в игровой форме. Девочки с легкостью  запоминают  новые иностранные слова с помощью пения, игры, рисования  и многого другого.   Особое внимание при этом  уделяется живому общению и произношению. </p><p>Занятия  проходят  в уютной располагающей атмосфере, где педагоги  создают дружелюбную мотивирующую атмосферу, чтобы дети полюбили занятия. В классах создается  живая  англоговорящая  среда, где малышки  учатся говорить, понимать и думать на английском.</p>',
        pic: 'angliyskiy.jpg'
      }, {
        name: 'Фотостайлинг',
        desc: '<p>Модные  наряды, легкая и грациозная походка, правильная осанка, отточенные движения и бесконечные фотовспышки, все это сопровождает результаты труда детского творчества. Девочки учатся правильно держаться перед камерой, позировать модному фотографу и не бояться  ярких вспышек камер. </p>',
        pic: 'foto.jpg'
      }, {
        name: 'Уроки высокой кухни',
        desc: '<p>Кулинарные кутюрье поделаться с будущими леди тайнами своему ремесла, и девочки сами смогут сотворить шедевр собственными руками на радость себе и своим близким. Домой они принесут вкусное печенье, пирожные и разные другие лакомства. </p>',
        pic: 'kuhna.jpg'
      }, {
        name: 'Дефиле',
        desc: '<p class="quot">Девочки освоят  навыки поведения на сцене. Занятия помогут им правильно  держать осанку,  красиво двигаться и дефилировать в разных тематических стилях.</p><p>Прежде всего, уроки дефиле помогают раскрыть яркую индивидуальность  девочек и, конечно же,   позволяют  маленьким леди демонстрировать   костюмы и наряды во всем их блеске и разнообразии. Каждое практическое занятие  заканчивается  фееричным и запоминающимся  для  детей выступлением.</p>',
        pic: 'defile.jpg'
      }, {
        name: 'Истроия искусств',
        desc: '<p class="quot">Малышки научатся  общаться с окружающим миром, с культурной средой.  Познакомятся с  самым  оптимистическим направлением в живописи как  Импрессионизм.</p><p>Девочки   научатся погружаться в переживание цвета и переживание души.  Уроки помогут  ученицам  стать  разносторонней личностью, развить  свои  таланты и научатся   понимать  себя и окружающий мир.  </p>',
        pic: 'istoria.jpg'
      }, {
        name: 'Психология',
        desc: '<p>Как известно, психология – это зонтик от неприятностей в любую погоду. Мы будем учиться выходить без конфликтов из спорных ситуаций. Будем учиться общаться! Как правильно сказать о своих потребностях. Как выразить свои чувства. Как помириться и как подружиться!</p>',
        pic: 'psichologia.jpg'
      }, {
        name: 'Детские мероприятия и балы',
        desc: '<p>в течение всего периода обучения девочки  посещают  светские  и культурные  мероприятия для детей своего возраста, которые помогают  маленьким леди  продемонстрировать в обществе свои  навыки  и умения, приобретенные в школе.  И конечно же получить яркие эмоции и впечатления  от детских праздников.</p>',
        pic: 'meropriatia.jpeg'
      }
    ]
  });
}

if (AuraPages.find({
  name: 'teens'
}).count() === 0) {
  AuraPages.insert({
    name: 'teens',
    heading: '<span>Школьная</span><span>группа</span>',
    mainPic: 'direction_bg3.jpg',
    mainDesc: '<p>	Леди, которая сегодня вызывает восхищение, еще вчера была девочкой лет 4-х… Как же происходит эта сказочная метаморфоза?</p><p> Все ценное закладывается  в детстве! Поэтому мы маленьких леди обучаем этикету  - как представиться, как попрощаться, за что отвечает каждая ложечка на столе…  Мы любуемся импрессионистами  и рисуем полет бабочки. Мы изучаем по сказкам Европы историю костюма!  Мы учимся красиво и без конфликта заявлять права на свою куклу в саду. Мы позируем … Играем в театр… И конечно, впервые открываем волшебный мир гардеробной. </p>',
    mainQuot: 'Австрийская Высшая Школа Леди в  г. Санкт-Петербург является одним из важнейших образовательных центров России для девочек  и девушек',
    classes: [
      {
        name: 'Этикет',
        desc: '<p class="quot">Как представиться. Как поприветствовать. Как попрощаться. В столовом этикете малыши будут изучать роль каждого столового прибора. И учиться пить чай по книгам Льюиса Кэролла</p> <p>Основные темы – столовый этикет и этикет общения. Программа этикета и хороших манер поможет развить устойчивые поведенческие навыки, которые позволят в дальнейшем чувствовать себя уверенно в любой ситуации, связанной с  общением. </p>',
        pic: 'etiket.jpg'
      }, {
        name: 'Стилистика',
        desc: '<p class="quot"> История костюма изучается по сказкам, по полотнам известных художников. Стили и стилевые направления для маленьких леди открываются через бренды, создающие коллекции для детей – от Dior до Dolce & Gabbana! </p><p>Они научатся отличать классический стиль от фольклорного, романтический от casual  и многое другое. Также мы будем изучать на практике гардероб настоящей Леди! Изучим темы от цвета (а ведь у каждого свой характер! И не все цвета хотят дружить друг с другом!) до сказочной темы шляпок и не только! </p>',
        pic: 'stilistika.jpg'
      }, {
        name: 'Имиджеология',
        desc: '<p>Девочки овладеют навыками искусства  самопрезентации с помощью практических занятий.. Узнают секреты как оставить  положительное впечатление в памяти своих друзей. Определят  свои сильные качества и  узнают  как их использовать в их детском мире. Научаться различать имидж плохого и хорошего героя на примере сказок. Узнают как формируется имидж в классе или в детском саду. Из чего имидж складывается, как формируется и как управляется.  </p>',
        pic: 'imidzeologia.jpg'
      }, {
        name: 'Верховая езда',
        desc: '<p class="quot"> Уроки верховой езды   проходят  в элитном конно-спортивном  клубе  «ДЕРБИ», расположенном  в живописном уголке Ленинградской области.  Ведь каждая будущая леди должна уметь уверенно держаться в седле, легко управляться с лошадью и вести светскую беседу.</p><p>Девочкам проводится краткий рассказ об истории отношений человека и лошади.  Первоначальные  практические занятия включают в себя  обучение правильной посадке, основам управления  </p>',
        pic: 'verhovaya.jpg'
      }, {
        name: 'Актерское мастерство',
        desc: '<p class="quot">Актерское мастерство - это быстрый и увлекательный способ научиться спонтанной импровизации.</p><p>В течение учебного процесса  девочки освободятся   от комплексов и  зажатости,  разовьют  в себе наблюдательность и вовлеченность в творческий процесс, а так же обретут  уверенность в себе. На практических занятиях девочки будут перевоплощаться в различные образы и готовить небольшие спектакли для благодарной родительской аудитории.  </p>',
        pic: 'akterskoe.jpg'
      }, {
        name: 'Хореография',
        desc: '<p class="quot">Главным достижением на уроках хореографии это – правильная осанка, пластичность, грациозность и легкость движений, уравновешенность, улучшение способности концентрироваться, укрепление здоровья, формирование сильного и гибкого тела.</p><p>В программу занятий входят упражнения по укреплению мышц и развития пластичности, постановку правильной осанки, походки, увеличения эластичности связок (растяжки), включая игровые и танцевальные элементы. </p>',
        pic: 'horeografia.jpg'
      }, {
        name: 'Английский язык',
        desc: '<p class="quot">Все занятия  проходят  в игровой форме. Девочки с легкостью  запоминают  новые иностранные слова с помощью пения, игры, рисования  и многого другого.   Особое внимание при этом  уделяется живому общению и произношению. </p><p>Занятия  проходят  в уютной располагающей атмосфере, где педагоги  создают дружелюбную мотивирующую атмосферу, чтобы дети полюбили занятия. В классах создается  живая  англоговорящая  среда, где малышки  учатся говорить, понимать и думать на английском.</p>',
        pic: 'angliyskiy.jpg'
      }, {
        name: 'Фотостайлинг',
        desc: '<p>Модные  наряды, легкая и грациозная походка, правильная осанка, отточенные движения и бесконечные фотовспышки, все это сопровождает результаты труда детского творчества. Девочки учатся правильно держаться перед камерой, позировать модному фотографу и не бояться  ярких вспышек камер. </p>',
        pic: 'foto.jpg'
      }, {
        name: 'Уроки высокой кухни',
        desc: '<p>Кулинарные кутюрье поделаться с будущими леди тайнами своему ремесла, и девочки сами смогут сотворить шедевр собственными руками на радость себе и своим близким. Домой они принесут вкусное печенье, пирожные и разные другие лакомства. </p>',
        pic: 'kuhna.jpg'
      }, {
        name: 'Дефиле',
        desc: '<p class="quot">Девочки освоят  навыки поведения на сцене. Занятия помогут им правильно  держать осанку,  красиво двигаться и дефилировать в разных тематических стилях.</p><p>Прежде всего, уроки дефиле помогают раскрыть яркую индивидуальность  девочек и, конечно же,   позволяют  маленьким леди демонстрировать   костюмы и наряды во всем их блеске и разнообразии. Каждое практическое занятие  заканчивается  фееричным и запоминающимся  для  детей выступлением.</p>',
        pic: 'defile.jpg'
      }, {
        name: 'Истроия искусств',
        desc: '<p class="quot">Малышки научатся  общаться с окружающим миром, с культурной средой.  Познакомятся с  самым  оптимистическим направлением в живописи как  Импрессионизм.</p><p>Девочки   научатся погружаться в переживание цвета и переживание души.  Уроки помогут  ученицам  стать  разносторонней личностью, развить  свои  таланты и научатся   понимать  себя и окружающий мир.  </p>',
        pic: 'istoria.jpg'
      }, {
        name: 'Психология',
        desc: '<p>Как известно, психология – это зонтик от неприятностей в любую погоду. Мы будем учиться выходить без конфликтов из спорных ситуаций. Будем учиться общаться! Как правильно сказать о своих потребностях. Как выразить свои чувства. Как помириться и как подружиться!</p>',
        pic: 'psichologia.jpg'
      }, {
        name: 'Детские мероприятия и балы',
        desc: '<p>в течение всего периода обучения девочки  посещают  светские  и культурные  мероприятия для детей своего возраста, которые помогают  маленьким леди  продемонстрировать в обществе свои  навыки  и умения, приобретенные в школе.  И конечно же получить яркие эмоции и впечатления  от детских праздников.</p>',
        pic: 'meropriatia.jpeg'
      }
    ]
  });
}

if (AuraPages.find({
  name: 'lateTeens'
}).count() === 0) {
  AuraPages.insert({
    name: 'lateTeens',
    heading: '<span>Подростковая</span><span>группа</span>',
    mainPic: 'direction_bg3.jpg',
    mainDesc: '<p>	Леди, которая сегодня вызывает восхищение, еще вчера была девочкой лет 4-х… Как же происходит эта сказочная метаморфоза?</p><p> Все ценное закладывается  в детстве! Поэтому мы маленьких леди обучаем этикету  - как представиться, как попрощаться, за что отвечает каждая ложечка на столе…  Мы любуемся импрессионистами  и рисуем полет бабочки. Мы изучаем по сказкам Европы историю костюма!  Мы учимся красиво и без конфликта заявлять права на свою куклу в саду. Мы позируем … Играем в театр… И конечно, впервые открываем волшебный мир гардеробной. </p>',
    mainQuot: 'Австрийская Высшая Школа Леди в  г. Санкт-Петербург является одним из важнейших образовательных центров России для девочек  и девушек',
    classes: [
      {
        name: 'Этикет',
        desc: '<p class="quot">Как представиться. Как поприветствовать. Как попрощаться. В столовом этикете малыши будут изучать роль каждого столового прибора. И учиться пить чай по книгам Льюиса Кэролла</p> <p>Основные темы – столовый этикет и этикет общения. Программа этикета и хороших манер поможет развить устойчивые поведенческие навыки, которые позволят в дальнейшем чувствовать себя уверенно в любой ситуации, связанной с  общением. </p>',
        pic: 'etiket.jpg'
      }, {
        name: 'Стилистика',
        desc: '<p class="quot"> История костюма изучается по сказкам, по полотнам известных художников. Стили и стилевые направления для маленьких леди открываются через бренды, создающие коллекции для детей – от Dior до Dolce & Gabbana! </p><p>Они научатся отличать классический стиль от фольклорного, романтический от casual  и многое другое. Также мы будем изучать на практике гардероб настоящей Леди! Изучим темы от цвета (а ведь у каждого свой характер! И не все цвета хотят дружить друг с другом!) до сказочной темы шляпок и не только! </p>',
        pic: 'stilistika.jpg'
      }, {
        name: 'Имиджеология',
        desc: '<p>Девочки овладеют навыками искусства  самопрезентации с помощью практических занятий.. Узнают секреты как оставить  положительное впечатление в памяти своих друзей. Определят  свои сильные качества и  узнают  как их использовать в их детском мире. Научаться различать имидж плохого и хорошего героя на примере сказок. Узнают как формируется имидж в классе или в детском саду. Из чего имидж складывается, как формируется и как управляется.  </p>',
        pic: 'imidzeologia.jpg'
      }, {
        name: 'Верховая езда',
        desc: '<p class="quot"> Уроки верховой езды   проходят  в элитном конно-спортивном  клубе  «ДЕРБИ», расположенном  в живописном уголке Ленинградской области.  Ведь каждая будущая леди должна уметь уверенно держаться в седле, легко управляться с лошадью и вести светскую беседу.</p><p>Девочкам проводится краткий рассказ об истории отношений человека и лошади.  Первоначальные  практические занятия включают в себя  обучение правильной посадке, основам управления  </p>',
        pic: 'verhovaya.jpg'
      }, {
        name: 'Актерское мастерство',
        desc: '<p class="quot">Актерское мастерство - это быстрый и увлекательный способ научиться спонтанной импровизации.</p><p>В течение учебного процесса  девочки освободятся   от комплексов и  зажатости,  разовьют  в себе наблюдательность и вовлеченность в творческий процесс, а так же обретут  уверенность в себе. На практических занятиях девочки будут перевоплощаться в различные образы и готовить небольшие спектакли для благодарной родительской аудитории.  </p>',
        pic: 'akterskoe.jpg'
      }, {
        name: 'Хореография',
        desc: '<p class="quot">Главным достижением на уроках хореографии это – правильная осанка, пластичность, грациозность и легкость движений, уравновешенность, улучшение способности концентрироваться, укрепление здоровья, формирование сильного и гибкого тела.</p><p>В программу занятий входят упражнения по укреплению мышц и развития пластичности, постановку правильной осанки, походки, увеличения эластичности связок (растяжки), включая игровые и танцевальные элементы. </p>',
        pic: 'horeografia.jpg'
      }, {
        name: 'Английский язык',
        desc: '<p class="quot">Все занятия  проходят  в игровой форме. Девочки с легкостью  запоминают  новые иностранные слова с помощью пения, игры, рисования  и многого другого.   Особое внимание при этом  уделяется живому общению и произношению. </p><p>Занятия  проходят  в уютной располагающей атмосфере, где педагоги  создают дружелюбную мотивирующую атмосферу, чтобы дети полюбили занятия. В классах создается  живая  англоговорящая  среда, где малышки  учатся говорить, понимать и думать на английском.</p>',
        pic: 'angliyskiy.jpg'
      }, {
        name: 'Фотостайлинг',
        desc: '<p>Модные  наряды, легкая и грациозная походка, правильная осанка, отточенные движения и бесконечные фотовспышки, все это сопровождает результаты труда детского творчества. Девочки учатся правильно держаться перед камерой, позировать модному фотографу и не бояться  ярких вспышек камер. </p>',
        pic: 'foto.jpg'
      }, {
        name: 'Уроки высокой кухни',
        desc: '<p>Кулинарные кутюрье поделаться с будущими леди тайнами своему ремесла, и девочки сами смогут сотворить шедевр собственными руками на радость себе и своим близким. Домой они принесут вкусное печенье, пирожные и разные другие лакомства. </p>',
        pic: 'kuhna.jpg'
      }, {
        name: 'Дефиле',
        desc: '<p class="quot">Девочки освоят  навыки поведения на сцене. Занятия помогут им правильно  держать осанку,  красиво двигаться и дефилировать в разных тематических стилях.</p><p>Прежде всего, уроки дефиле помогают раскрыть яркую индивидуальность  девочек и, конечно же,   позволяют  маленьким леди демонстрировать   костюмы и наряды во всем их блеске и разнообразии. Каждое практическое занятие  заканчивается  фееричным и запоминающимся  для  детей выступлением.</p>',
        pic: 'defile.jpg'
      }, {
        name: 'Истроия искусств',
        desc: '<p class="quot">Малышки научатся  общаться с окружающим миром, с культурной средой.  Познакомятся с  самым  оптимистическим направлением в живописи как  Импрессионизм.</p><p>Девочки   научатся погружаться в переживание цвета и переживание души.  Уроки помогут  ученицам  стать  разносторонней личностью, развить  свои  таланты и научатся   понимать  себя и окружающий мир.  </p>',
        pic: 'istoria.jpg'
      }, {
        name: 'Психология',
        desc: '<p>Как известно, психология – это зонтик от неприятностей в любую погоду. Мы будем учиться выходить без конфликтов из спорных ситуаций. Будем учиться общаться! Как правильно сказать о своих потребностях. Как выразить свои чувства. Как помириться и как подружиться!</p>',
        pic: 'psichologia.jpg'
      }, {
        name: 'Детские мероприятия и балы',
        desc: '<p>в течение всего периода обучения девочки  посещают  светские  и культурные  мероприятия для детей своего возраста, которые помогают  маленьким леди  продемонстрировать в обществе свои  навыки  и умения, приобретенные в школе.  И конечно же получить яркие эмоции и впечатления  от детских праздников.</p>',
        pic: 'meropriatia.jpeg'
      }
    ]
  });
}

if (AuraPages.find({
  name: 'grownUps'
}).count() === 0) {
  AuraPages.insert({
    name: 'grownUps',
    heading: '<span>Взрослая</span><span>группа</span>',
    mainPic: 'direction_bg3.jpg',
    mainDesc: '<p>	Леди, которая сегодня вызывает восхищение, еще вчера была девочкой лет 4-х… Как же происходит эта сказочная метаморфоза?</p><p> Все ценное закладывается  в детстве! Поэтому мы маленьких леди обучаем этикету  - как представиться, как попрощаться, за что отвечает каждая ложечка на столе…  Мы любуемся импрессионистами  и рисуем полет бабочки. Мы изучаем по сказкам Европы историю костюма!  Мы учимся красиво и без конфликта заявлять права на свою куклу в саду. Мы позируем … Играем в театр… И конечно, впервые открываем волшебный мир гардеробной. </p>',
    mainQuot: 'Австрийская Высшая Школа Леди в  г. Санкт-Петербург является одним из важнейших образовательных центров России для девочек  и девушек',
    classes: [
      {
        name: 'Этикет',
        desc: '<p class="quot">Как представиться. Как поприветствовать. Как попрощаться. В столовом этикете малыши будут изучать роль каждого столового прибора. И учиться пить чай по книгам Льюиса Кэролла</p> <p>Основные темы – столовый этикет и этикет общения. Программа этикета и хороших манер поможет развить устойчивые поведенческие навыки, которые позволят в дальнейшем чувствовать себя уверенно в любой ситуации, связанной с  общением. </p>',
        pic: 'etiket.jpg'
      }, {
        name: 'Стилистика',
        desc: '<p class="quot"> История костюма изучается по сказкам, по полотнам известных художников. Стили и стилевые направления для маленьких леди открываются через бренды, создающие коллекции для детей – от Dior до Dolce & Gabbana! </p><p>Они научатся отличать классический стиль от фольклорного, романтический от casual  и многое другое. Также мы будем изучать на практике гардероб настоящей Леди! Изучим темы от цвета (а ведь у каждого свой характер! И не все цвета хотят дружить друг с другом!) до сказочной темы шляпок и не только! </p>',
        pic: 'stilistika.jpg'
      }, {
        name: 'Имиджеология',
        desc: '<p>Девочки овладеют навыками искусства  самопрезентации с помощью практических занятий.. Узнают секреты как оставить  положительное впечатление в памяти своих друзей. Определят  свои сильные качества и  узнают  как их использовать в их детском мире. Научаться различать имидж плохого и хорошего героя на примере сказок. Узнают как формируется имидж в классе или в детском саду. Из чего имидж складывается, как формируется и как управляется.  </p>',
        pic: 'imidzeologia.jpg'
      }, {
        name: 'Верховая езда',
        desc: '<p class="quot"> Уроки верховой езды   проходят  в элитном конно-спортивном  клубе  «ДЕРБИ», расположенном  в живописном уголке Ленинградской области.  Ведь каждая будущая леди должна уметь уверенно держаться в седле, легко управляться с лошадью и вести светскую беседу.</p><p>Девочкам проводится краткий рассказ об истории отношений человека и лошади.  Первоначальные  практические занятия включают в себя  обучение правильной посадке, основам управления  </p>',
        pic: 'verhovaya.jpg'
      }, {
        name: 'Актерское мастерство',
        desc: '<p class="quot">Актерское мастерство - это быстрый и увлекательный способ научиться спонтанной импровизации.</p><p>В течение учебного процесса  девочки освободятся   от комплексов и  зажатости,  разовьют  в себе наблюдательность и вовлеченность в творческий процесс, а так же обретут  уверенность в себе. На практических занятиях девочки будут перевоплощаться в различные образы и готовить небольшие спектакли для благодарной родительской аудитории.  </p>',
        pic: 'akterskoe.jpg'
      }, {
        name: 'Хореография',
        desc: '<p class="quot">Главным достижением на уроках хореографии это – правильная осанка, пластичность, грациозность и легкость движений, уравновешенность, улучшение способности концентрироваться, укрепление здоровья, формирование сильного и гибкого тела.</p><p>В программу занятий входят упражнения по укреплению мышц и развития пластичности, постановку правильной осанки, походки, увеличения эластичности связок (растяжки), включая игровые и танцевальные элементы. </p>',
        pic: 'horeografia.jpg'
      }, {
        name: 'Английский язык',
        desc: '<p class="quot">Все занятия  проходят  в игровой форме. Девочки с легкостью  запоминают  новые иностранные слова с помощью пения, игры, рисования  и многого другого.   Особое внимание при этом  уделяется живому общению и произношению. </p><p>Занятия  проходят  в уютной располагающей атмосфере, где педагоги  создают дружелюбную мотивирующую атмосферу, чтобы дети полюбили занятия. В классах создается  живая  англоговорящая  среда, где малышки  учатся говорить, понимать и думать на английском.</p>',
        pic: 'angliyskiy.jpg'
      }, {
        name: 'Фотостайлинг',
        desc: '<p>Модные  наряды, легкая и грациозная походка, правильная осанка, отточенные движения и бесконечные фотовспышки, все это сопровождает результаты труда детского творчества. Девочки учатся правильно держаться перед камерой, позировать модному фотографу и не бояться  ярких вспышек камер. </p>',
        pic: 'foto.jpg'
      }, {
        name: 'Уроки высокой кухни',
        desc: '<p>Кулинарные кутюрье поделаться с будущими леди тайнами своему ремесла, и девочки сами смогут сотворить шедевр собственными руками на радость себе и своим близким. Домой они принесут вкусное печенье, пирожные и разные другие лакомства. </p>',
        pic: 'kuhna.jpg'
      }, {
        name: 'Дефиле',
        desc: '<p class="quot">Девочки освоят  навыки поведения на сцене. Занятия помогут им правильно  держать осанку,  красиво двигаться и дефилировать в разных тематических стилях.</p><p>Прежде всего, уроки дефиле помогают раскрыть яркую индивидуальность  девочек и, конечно же,   позволяют  маленьким леди демонстрировать   костюмы и наряды во всем их блеске и разнообразии. Каждое практическое занятие  заканчивается  фееричным и запоминающимся  для  детей выступлением.</p>',
        pic: 'defile.jpg'
      }, {
        name: 'Истроия искусств',
        desc: '<p class="quot">Малышки научатся  общаться с окружающим миром, с культурной средой.  Познакомятся с  самым  оптимистическим направлением в живописи как  Импрессионизм.</p><p>Девочки   научатся погружаться в переживание цвета и переживание души.  Уроки помогут  ученицам  стать  разносторонней личностью, развить  свои  таланты и научатся   понимать  себя и окружающий мир.  </p>',
        pic: 'istoria.jpg'
      }, {
        name: 'Психология',
        desc: '<p>Как известно, психология – это зонтик от неприятностей в любую погоду. Мы будем учиться выходить без конфликтов из спорных ситуаций. Будем учиться общаться! Как правильно сказать о своих потребностях. Как выразить свои чувства. Как помириться и как подружиться!</p>',
        pic: 'psichologia.jpg'
      }, {
        name: 'Детские мероприятия и балы',
        desc: '<p>в течение всего периода обучения девочки  посещают  светские  и культурные  мероприятия для детей своего возраста, которые помогают  маленьким леди  продемонстрировать в обществе свои  навыки  и умения, приобретенные в школе.  И конечно же получить яркие эмоции и впечатления  от детских праздников.</p>',
        pic: 'meropriatia.jpeg'
      }
    ]
  });
}

Meteor.startup(function() {
  var user, user2, user3;
  if (Meteor.users.find().count() === 0) {
    user = Accounts.createUser({
      username: 'ksusha',
      email: 'bastrikina2011@yandex.ru',
      password: '12345678',
      profile: {
        name: 'Ксения',
        surname: 'Бастрыкина',
        pic: 'ksusha.jpg'
      }
    });
    user2 = Accounts.createUser({
      username: 'masha',
      email: 'maria-skr-rt@mail.ru',
      password: '12345678',
      profile: {
        name: 'Мария',
        surname: 'Бастрыкина',
        pic: 'masha.jpg'
      }
    });
    user3 = Accounts.createUser({
      username: 'albert_kai',
      email: 'albertkai@me.com',
      password: '12345678',
      profile: {
        name: 'Альберт',
        surname: 'Кайгородов',
        pic: 'albert.jpg'
      }
    });
    Roles.addUsersToRoles(user, ['owner']);
    Roles.addUsersToRoles(user2, ['owner']);
    Roles.addUsersToRoles(user3, ['admin']);
  }
  console.log(AuraPages.find().fetch());
  return console.log('hello');
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['aura:core'] = {};

})();

//# sourceMappingURL=aura_core.js.map
