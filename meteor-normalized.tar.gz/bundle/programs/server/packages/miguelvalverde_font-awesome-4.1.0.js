(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['miguelvalverde:font-awesome-4.1.0'] = {};

})();

//# sourceMappingURL=miguelvalverde_font-awesome-4.1.0.js.map
