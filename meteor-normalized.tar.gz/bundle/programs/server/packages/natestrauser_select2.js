(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['natestrauser:select2'] = {};

})();

//# sourceMappingURL=natestrauser_select2.js.map
