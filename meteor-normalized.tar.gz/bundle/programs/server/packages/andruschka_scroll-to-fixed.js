(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['andruschka:scroll-to-fixed'] = {};

})();

//# sourceMappingURL=andruschka_scroll-to-fixed.js.map
